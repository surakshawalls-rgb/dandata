import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  OnInit,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth';
import { Supabase } from '../../core/services/supabase';

interface DonationForm {
  donorName: string;
  mobile: string;
  address: string;
  amount: number | null;
  donationDate: string;
}

@Component({
  selector: 'app-admin-donation',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './admin-donation.component.html',
  styleUrl: './admin-donation.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminDonationComponent
  implements OnInit
{
  form: DonationForm = {
    donorName: '',
    mobile: '',
    address: '',
    amount: null,
    donationDate: this.getToday(),
  };

  saving = false;
  saved = false;
  errorMessage = '';
  whatsappUrl = '';

  constructor(
    private readonly auth: AuthService,
    private readonly supabase: Supabase,
    private readonly router: Router,
    private readonly cdr: ChangeDetectorRef,
  ) {}

  async ngOnInit(): Promise<void> {
    await this.auth.waitForInitialization();

    const user = this.auth.getUser();

    if (!user) {
      await this.router.navigate([
        '/login',
      ]);
      return;
    }

    this.cdr.markForCheck();
  }

  async saveDonation(): Promise<void> {
    if (this.saving) {
      return;
    }

    this.errorMessage = '';
    this.saved = false;

    if (!this.isFormValid()) {
      this.errorMessage =
        'Please fill in all required fields correctly.';

      this.cdr.markForCheck();
      return;
    }

    this.saving = true;
    this.cdr.markForCheck();

    try {
      const {
        data: organization,
        error: organizationError,
      } = await this.supabase
        .from('organizations')
        .select('id')
        .eq('slug', 'daandata')
        .maybeSingle();

      if (organizationError) {
        throw organizationError;
      }

      if (!organization) {
        throw new Error(
          'Samiti organization was not found.',
        );
      }

      const {
        data: donor,
        error: donorError,
      } = await this.supabase
        .from('donors')
        .insert({
          organization_id:
            organization.id,
          full_name:
            this.form.donorName.trim(),
          phone:
            this.form.mobile.trim(),
          address:
            this.form.address.trim(),
          is_anonymous: false,
          is_active: true,
        })
        .select('id')
        .single();

      if (donorError) {
        throw donorError;
      }

      const {
        data: donation,
        error: donationError,
      } = await this.supabase
        .from('donations')
        .insert({
          organization_id:
            organization.id,
          donor_id:
            donor.id,
          amount:
            this.form.amount,
          currency: 'INR',
          payment_method: 'cash',
          payment_status: 'successful',
          donor_name_snapshot:
            this.form.donorName.trim(),
          donated_at:
            `${this.form.donationDate}T12:00:00`,
        })
        .select('id')
        .single();

      if (donationError) {
        throw donationError;
      }

      this.whatsappUrl =
        this.createWhatsAppUrl(
          donation.id,
        );

      this.saved = true;

      /*
       * Tell Angular to refresh the page immediately
       * after the Supabase save has completed.
       */
      this.cdr.markForCheck();
    } catch (error) {
      console.error(
        'Failed to save donation:',
        error,
      );

      this.errorMessage =
        'Unable to save the donation. Please try again.';

      this.cdr.markForCheck();
    } finally {
      this.saving = false;
      this.cdr.markForCheck();
    }
  }

  openWhatsApp(): void {
    if (!this.whatsappUrl) {
      return;
    }

    window.open(
      this.whatsappUrl,
      '_blank',
      'noopener,noreferrer',
    );
  }

  goBack(): void {
    void this.router.navigate([
      '/admin',
    ]);
  }

  private isFormValid(): boolean {
    const mobile =
      this.form.mobile.replace(
        /\D/g,
        '',
      );

    return (
      this.form.donorName.trim().length > 0 &&
      mobile.length >= 10 &&
      this.form.address.trim().length > 0 &&
      this.form.amount !== null &&
      this.form.amount > 0 &&
      this.form.donationDate.length > 0
    );
  }

  private createWhatsAppUrl(
    donationId: string,
  ): string {
    const mobile =
      this.normaliseMobile(
        this.form.mobile,
      );

    const amount =
      this.formatAmount(
        Number(this.form.amount),
      );

    const message = [
      'Donation Confirmation',
      '',
      `Donor: ${this.form.donorName.trim()}`,
      `Amount: ${amount}`,
      `Date: ${this.form.donationDate}`,
      `Address: ${this.form.address.trim()}`,
      `Transaction ID: ${donationId}`,
      '',
      'Thank you for your valuable contribution to the Samiti.',
    ].join('\n');

    return `https://wa.me/${mobile}?text=${encodeURIComponent(message)}`;
  }

  private normaliseMobile(
    mobile: string,
  ): string {
    const digits =
      mobile.replace(
        /\D/g,
        '',
      );

    if (digits.startsWith('91')) {
      return digits;
    }

    return `91${digits}`;
  }

  private formatAmount(
    amount: number,
  ): string {
    return new Intl.NumberFormat(
      'en-IN',
      {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0,
      },
    ).format(amount);
  }

  private getToday(): string {
    const now = new Date();

    const year =
      now.getFullYear();

    const month =
      String(
        now.getMonth() + 1,
      ).padStart(2, '0');

    const day =
      String(
        now.getDate(),
      ).padStart(2, '0');

    return `${year}-${month}-${day}`;
  }
}